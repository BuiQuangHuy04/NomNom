create
    definer = root@localhost procedure proc3(IN id char(10))
begin
    select distinct C.cus_name as ten_khach_hang,
                    P.cus_id as ma_khach_hang,
                    D.dep_amount as so_tien_gui,
                    tim_term_deposits as ky_han_gui,
                    round(datediff(date(now()),dep_date)/30,0) as so_thang_da_gui,
#                     P.dep_amount as tien_cong_them,
                    round(D.dep_amount*(tim_interest_rate/100/12*tim_term_deposits+1),0) as so_du_tam_tinh
    from tbl_deposits D, tbl_timelimits T, tbl_customers C,tbl_promotion P
    where D.tim_id=T.tim_id
    and D.cus_id=C.cus_id
    and D.cus_id=P.cus_id
    and C.cus_id=P.cus_id
    and P.cus_id = id;
end;

