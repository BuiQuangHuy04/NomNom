create
    definer = root@localhost procedure proc1(IN id char(10))
begin
    select tbl_customers.cus_name as ten_khach_hang,
           dep_amount as so_du_ban_dau,
           bak_name as ten_ngan_hang,
           tim_term_deposits as ky_han_gui,
           dep_date as ngay_gui,
           round(dep_amount*(tim_interest_rate/100/12*tim_term_deposits+1),0) as so_du_cuoi
    from tbl_customers,tbl_timelimits,tbl_deposits,tbl_banks
    where tbl_deposits.cus_id=tbl_customers.cus_id
    and tbl_deposits.tim_id=tbl_timelimits.tim_id
    and tbl_banks.bak_id=tbl_timelimits.bak_id
    and tbl_customers.cus_id=id
    ;
end;

