create
    definer = root@localhost procedure proc2()
begin
    declare cid char(10);
    declare da bigint;
    declare ttd int;
    declare dd date;
    declare flag char(1) default 'y';
    declare ddif int default 0;
    declare cur cursor for
        select C.cus_id,
               T.tim_term_deposits,
               D.dep_date
        from tbl_customers C
                 inner join tbl_deposits D on D.cus_id = C.cus_id
                 inner join tbl_timelimits T on D.tim_id = T.tim_id;
    declare continue handler for not found set flag = 'n';
    open cur;
    wloop: while flag = 'y' do
            begin
                fetch cur into cid,ttd,dd;
                if flag = 'n' then
                    leave wloop;
                end if;
                if ttd=6 then
                    begin
                        set ddif =(
                            select abs(period_diff(date_format(curdate(),'%Y%m'),date_format(dd,'%Y%m'))));
                        if ddif >= 36 then
                            insert into tbl_promotion(cus_id, dep_amount) VALUES (cid,15);
                        end if;
                    end;
                end if;
                if ttd=12 then
                    begin
                        set ddif =(
                            select abs(period_diff(date_format(curdate(),'%Y%m'),date_format(dd,'%Y%m'))));
                        if ddif >= 36 then
                            insert into tbl_promotion(cus_id, dep_amount) VALUES (cid,25);
                        end if;
                    end;
                end if;
                if ttd=24 then
                    begin
                        set ddif =(
                            select abs(period_diff(date_format(curdate(),'%Y%m'),date_format(dd,'%Y%m'))));
                        if ddif >= 36 then
                            insert into tbl_promotion(cus_id, dep_amount) VALUES (cid,55);
                        end if;
                    end;
                end if;
            end;
        end while;
    close cur;
end;

